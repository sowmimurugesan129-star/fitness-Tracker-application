# Fitness Tracking Application

Java Swing + SQLite JDBC college mini project.

## Features
Login, dashboard, profile, daily tracking, BMI, fitness score, goals, workout management, preview-before-save, confirm & save, history, and reports.

## Login
Username: admin
Password: admin123

## Requirements
JDK 17+ and Maven 3.9+. Maven downloads the SQLite JDBC dependency on the first run.

## Run in VS Code
Open this folder. In Terminal run:

mvn clean compile
mvn exec:java

The database file `fitness_tracker.db` is created automatically.

This is an educational fitness-tracking application. Scores and BMI are general tracking metrics, not medical diagnosis.
